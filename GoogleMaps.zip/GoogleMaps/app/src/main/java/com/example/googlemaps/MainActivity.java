package com.example.googlemaps;

import static com.google.android.gms.maps.CameraUpdateFactory.newLatLngZoom;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;

public class MainActivity
        extends FragmentActivity
implements OnMapReadyCallback {

GoogleMap mapa;
@Override
        protected void onCreate(Bundle savedIntanceState) {
super.onCreate(savedIntanceState);
setContentView(R.layout.activity_main);
    SupportMapFragment mapFragment = (SupportMapFragment)
            getSupportFragmentManager()
                    .findFragmentById(R.id.map);
mapFragment.getMapAsync(this);

        }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mapa = googleMap;
        mapa.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
        mapa.getUiSettings().setZoomControlsEnabled(true);

//para movernos en el mapa
      // CameraUpdate camUdp1=
             //  CameraUpdateFactory;
                    //   newLatLngZoom (new LatLng(40.68927699058223, -74.04449230643827));

        LatLng madrid = new LatLng(40.68927699058223, -74.04449230643827);
        CameraPosition camPos = new CameraPosition.Builder()
                .target(madrid)
                .zoom(25)
                .bearing(1) //noreste arriba
                .tilt(90) //punto de vista de la cámara 70 grados
                .build();
        CameraUpdate camUpd3 =
                CameraUpdateFactory.newCameraPosition(camPos);
        mapa.animateCamera(camUpd3);
    }
    }
